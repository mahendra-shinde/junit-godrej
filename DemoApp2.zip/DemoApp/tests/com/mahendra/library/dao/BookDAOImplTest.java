package com.mahendra.library.dao;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.mahendra.library.models.Book;

public class BookDAOImplTest {
	static Book book;
	private static BookDAO dao =null; 
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		book = new Book(101, "Yayati", "Novel in marathi", 'A');
		dao = new BookDAOImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		book = null;
		dao = null;
	}

	@Test
	public void testSave() {
		//try to save sample book
		int result = dao.save(book);
		assertNotEquals(0, result); //Inform JUnit, you DO NOT EXPECT ZERO!!
	}

	@Test
	public void testFindById() {
		//Try searching for a book
		Book b1 = dao.findById(101);
		assertNotNull(b1);	//Expecting a not null object!
	}

}
