package com.mahendra.library.models;

import static org.junit.Assert.*;
import org.junit.*;

public class BookTest {
	Book b = new Book();
	
	@Before
	public void init() {
		b.setTitle("Let us C");
		System.out.println("Sample Data Set!");
	}
	
	@After
	public void clean() {
		b.setTitle("");
		System.out.println("Sample Data Cleaned!");
	}
	
	@Test
	public void testGetTitle() {
		assertEquals("Let us C", b.getTitle());
		
		assertEquals("Failed!", 102.22,102.221, 0.01);

		
	}

	@Test
	public void testSetTitle() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetDescription() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetDescription() {
		fail("Not yet implemented");
	}

}
