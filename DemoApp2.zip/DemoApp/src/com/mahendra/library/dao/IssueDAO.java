package com.mahendra.library.dao;

public interface IssueDAO {
	int issueBook(int bookId, int memberId);
	
}
