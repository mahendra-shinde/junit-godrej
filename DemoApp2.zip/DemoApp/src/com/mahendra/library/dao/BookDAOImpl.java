package com.mahendra.library.dao;

import com.mahendra.library.models.Book;

public class BookDAOImpl  implements BookDAO{

	@Override
	public int save(Book book) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Book findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
